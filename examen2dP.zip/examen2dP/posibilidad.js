class Posibilidad {
    lanzar() { 
        return Math.floor(Math.random() * 10) + 1;
    }
}